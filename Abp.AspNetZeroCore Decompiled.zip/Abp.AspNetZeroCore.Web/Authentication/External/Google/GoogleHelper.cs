﻿using Newtonsoft.Json.Linq;
using System;

namespace Abp.AspNetZeroCore.Web.Authentication.External.Google
{
    public static class GoogleHelper
    {
        public static string GetId(JObject user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            return (string)((JToken)user).Value<string>((object)"id");
        }

        public static string GetName(JObject user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            return (string)((JToken)user).Value<string>((object)"name");
        }

        public static string GetGivenName(JObject user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            return (string)((JToken)user).Value<string>((object)"given_name");
        }

        public static string GetFamilyName(JObject user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            return (string)((JToken)user).Value<string>((object)"family_name");
        }

        public static string GetProfile(JObject user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            return (string)((JToken)user).Value<string>((object)"link");
        }

        public static string GetEmail(JObject user)
        {
            if (user == null)
                throw new ArgumentNullException(nameof(user));
            return (string)((JToken)user).Value<string>((object)"email");
        }

        private static string TryGetValue(JObject user, string propertyName, string subProperty)
        {
            JToken jtoken;
            if (user.TryGetValue(propertyName, out jtoken))
            {
                JObject jobject = JObject.Parse(((object)jtoken).ToString());
                if (jobject != null && jobject.TryGetValue(subProperty, out jtoken))
                    return ((object)jtoken).ToString();
            }
            return (string)null;
        }

        private static string TryGetFirstValue(JObject user, string propertyName, string subProperty)
        {
            JToken jtoken;
            if (user.TryGetValue(propertyName, out jtoken))
            {
                JArray jarray = JArray.Parse(((object)jtoken).ToString());
                if (jarray != null && ((JContainer)jarray).Count > 0)
                {
                    JObject jobject = JObject.Parse(((object)((JToken)jarray).First).ToString());
                    if (jobject != null && jobject.TryGetValue(subProperty, out jtoken))
                        return ((object)jtoken).ToString();
                }
            }
            return (string)null;
        }
    }
}
