﻿using System.Collections.Generic;

namespace Abp.AspNetZeroCore.Web.Authentication.External
{
    public interface IExternalAuthConfiguration
    {
        List<ExternalLoginProviderInfo> Providers { get; }
    }
}
