﻿using Microsoft.AspNetCore.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;

namespace Abp.AspNetZeroCore.Web.Authentication.External
{
    public static class RemoteAuthenticationContextExtensions
    {
        public static void AddMappedClaims<TOptions>(
          this RemoteAuthenticationContext<TOptions> context,
          List<JsonClaimMap> mappings)
          where TOptions : RemoteAuthenticationOptions
        {
            if (!mappings.Any<JsonClaimMap>())
                return;
            foreach (JsonClaimMap mapping in mappings)
            {
                JsonClaimMap claimMapping = mapping;
                Claim claim = context.Principal.Claims.ToList<Claim>().FirstOrDefault<Claim>((Func<Claim, bool>)(c => c.Type == claimMapping.Key));
                if (claim != null)
                    context.Principal.AddIdentity(new ClaimsIdentity((IEnumerable<Claim>)new List<Claim>()
          {
            new Claim(claimMapping.Claim, claim.Value)
          }));
            }
        }
    }
}
