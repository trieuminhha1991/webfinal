﻿using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;

namespace Abp.AspNetZeroCore.Web.Authentication.External.OpenIdConnect
{
    public class OpenIdConnectAuthProviderApi : ExternalAuthProviderApiBase
    {
        public const string Name = "OpenIdConnect";

        public override async Task<ExternalAuthUserInfo> GetUserInfo(string token)
        {
            var issuer = ProviderInfo.AdditionalParams["Authority"];
            if (string.IsNullOrEmpty(issuer))
            {
                throw new ApplicationException("Authentication:OpenId:Issuer configuration is required.");
            }

            var configurationManager = new ConfigurationManager<OpenIdConnectConfiguration>(
                issuer + "/.well-known/openid-configuration",
                new OpenIdConnectConfigurationRetriever(),
                new HttpDocumentRetriever());

            var validatedToken = await ValidateToken(token, issuer, configurationManager);

            var fullName = validatedToken.Claims.First(c => c.Type == "name").Value;
            var email = validatedToken.Claims.First(c => c.Type == "unique_name").Value;
            var fullNameParts = fullName.Split(' ');

            return new ExternalAuthUserInfo
            {
                Provider = Name,
                ProviderKey = validatedToken.Subject,
                Name = fullNameParts[0],
                Surname = fullNameParts[1],
                EmailAddress = email
            };
        }

        private async Task<JwtSecurityToken> ValidateToken(
            string token,
            string issuer,
            IConfigurationManager<OpenIdConnectConfiguration> configurationManager,
            CancellationToken ct = default(CancellationToken))
        {
            if (string.IsNullOrEmpty(token))
            {
                throw new ArgumentNullException(nameof(token));
            }

            if (string.IsNullOrEmpty(issuer))
            {
                throw new ArgumentNullException(nameof(issuer));
            }

            var discoveryDocument = await configurationManager.GetConfigurationAsync(ct);
            var signingKeys = discoveryDocument.SigningKeys;

            var validationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = issuer,
                ValidateIssuerSigningKey = true,
                IssuerSigningKeys = signingKeys,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(5),
                ValidateAudience = false
            };

            var principal = new JwtSecurityTokenHandler().ValidateToken(token, validationParameters, out var rawValidatedToken);
            //Validate clientId
            if (ProviderInfo.ClientId != principal.Claims.First(c => c.Type == "aud").Value)
            {
                throw new ApplicationException("ClientId couldn't verified.");
            }

            return (JwtSecurityToken)rawValidatedToken;
        }

    }
}
