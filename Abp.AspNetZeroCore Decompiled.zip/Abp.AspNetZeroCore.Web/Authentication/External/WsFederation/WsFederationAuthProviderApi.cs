﻿
using Microsoft.IdentityModel.Protocols;
using Microsoft.IdentityModel.Protocols.WsFederation;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading;
using System.Threading.Tasks;

namespace Abp.AspNetZeroCore.Web.Authentication.External.WsFederation
{
    public class WsFederationAuthProviderApi : ExternalAuthProviderApiBase
    {
        public const string Name = "WsFederation";

        public override async Task<ExternalAuthUserInfo> GetUserInfo(string token)
        {
            WsFederationAuthProviderApi federationAuthProviderApi = this;
            // ISSUE: explicit non-virtual call
            //string additionalParam1 = __nonvirtual (federationAuthProviderApi.ProviderInfo).AdditionalParams["Authority"];
            var issuer = ProviderInfo.AdditionalParams["Authority"];
            if (string.IsNullOrEmpty(issuer))
                throw new ApplicationException("Authentication:WsFederation:Issuer configuration is required.");
            // ISSUE: explicit non-virtual call
            //string additionalParam2 = __nonvirtual (federationAuthProviderApi.ProviderInfo).AdditionalParams["MetaDataAddress"];
            var address = ProviderInfo.AdditionalParams["MetaDataAddress"];
            if (string.IsNullOrEmpty(address))
                throw new ApplicationException("Authentication:WsFederation:MetaDataAddress configuration is required.");

            WsFederationConfigurationRetriever configurationRetriever = new WsFederationConfigurationRetriever();
            HttpDocumentRetriever documentRetriever = new HttpDocumentRetriever();
            ConfigurationManager<WsFederationConfiguration> configurationManager = new ConfigurationManager<WsFederationConfiguration>(address, (IConfigurationRetriever<WsFederationConfiguration>)configurationRetriever, (IDocumentRetriever)documentRetriever);

            JwtSecurityToken jwtSecurityToken = await federationAuthProviderApi.ValidateToken(token, issuer, (IConfigurationManager<WsFederationConfiguration>)configurationManager, new CancellationToken());
            string fullName = jwtSecurityToken.Claims.First<Claim>((Func<Claim, bool>)(c => c.Type == "name")).Value;
            string email = jwtSecurityToken.Claims.First<Claim>((Func<Claim, bool>)(c => c.Type == "email")).Value;
            string[] fullNameParts = fullName.Split(' ');
            return new ExternalAuthUserInfo()
            {
                Provider = "WsFederation",
                ProviderKey = jwtSecurityToken.Subject,
                Name = fullNameParts[0],
                Surname = fullNameParts.Length > 1 ? fullNameParts[1] : fullNameParts[0],
                EmailAddress = email
            };
        }

        private async Task<JwtSecurityToken> ValidateToken(
          string token,
          string issuer,
          IConfigurationManager<WsFederationConfiguration> configurationManager,
          CancellationToken ct = default(CancellationToken))
        {
            WsFederationAuthProviderApi federationAuthProviderApi = this;
            if (string.IsNullOrEmpty(token))
                throw new ArgumentNullException(nameof(token));
            if (string.IsNullOrEmpty(issuer))
                throw new ArgumentNullException(nameof(issuer));

            //ICollection<SecurityKey> signingKeys = (await configurationManager.GetConfigurationAsync(ct)).get_SigningKeys();
            var discoveryDocument = await configurationManager.GetConfigurationAsync(ct);
            var signingKeys = discoveryDocument.SigningKeys;

            SecurityToken validatedToken;
            ClaimsPrincipal claimsPrincipal = new JwtSecurityTokenHandler().ValidateToken(token, new TokenValidationParameters()
            {
                ValidateIssuer = true,
                ValidIssuer = issuer,
                ValidateIssuerSigningKey = true,
                IssuerSigningKeys = (IEnumerable<SecurityKey>)signingKeys,
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromMinutes(5.0),
                ValidateAudience = false
            }, out validatedToken);

            // ISSUE: explicit non-virtual call

            //var principal = new JwtSecurityTokenHandler().ValidateToken(token, validationParameters, out var rawValidatedToken);
            if (ProviderInfo.ClientId != claimsPrincipal.Claims.First<Claim>((Func<Claim, bool>)(c => c.Type == "aud")).Value)
                throw new ApplicationException("ClientId couldn't verified.");
            return (JwtSecurityToken)validatedToken;
        }
    }
}
