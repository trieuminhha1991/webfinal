﻿namespace Abp.AspNetZeroCore.Web.Authentication.External
{
    public class JsonClaimMap
    {
        public string Claim { get; set; }

        public string Key { get; set; }
    }
}
