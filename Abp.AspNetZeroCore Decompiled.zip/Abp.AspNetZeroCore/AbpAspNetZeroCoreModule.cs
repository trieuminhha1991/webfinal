﻿using Abp.Modules;
using Abp.Reflection.Extensions;
using System;

namespace Abp.AspNetZeroCore
{
    public class AbpAspNetZeroCoreModule : AbpModule
    {
        public override void Initialize()
        {
            //base.IocManager.RegisterAssemblyByConvention(TypeExtensions.GetAssembly(typeof(AbpAspNetZeroCoreModule)));

            //IocManager.RegisterAssemblyByConvention(typeof(AbpZeroTemplateApplicationModule).GetAssembly());

            this.IocManager.RegisterAssemblyByConvention(typeof(AbpAspNetZeroCoreModule).GetAssembly());
        }
    }
}
